import React from 'react';

// Just add this feature if you want :P

const UserWishListTab = () => (
  <div className="loader" style={{ minHeight: '80vh' }}>
    <h3>My Wish List</h3>
    <strong><span className="text-subtle">You don&apos;t have a wish list</span></strong>
  </div>
);

export default UserWishListTab;
